package monitoring.agent;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.management.*;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;

public class wlsMonitor {
    private final String USER_AGENT = "Mozilla/5.0";
    private static MBeanServerConnection connection;
    private static JMXConnector connector;
    private static final ObjectName service;
    private static String servers[] = new String[40];
    private static String checkURLs[] = new String[80];
    private static String serviceName;
    private static String adminConsoleIP;
    private static String adminConsolePort;
    private static String adminUsername;
    private static String adminPassword;
    private static String serviceURL;

    private static int monitoringInstanceCount;
    private Map mBeanMap = new HashMap();
    private Map jvmRuntimeMap = new HashMap();
    private Map serverRuntimeMap = new HashMap();
    private Map threadPoolRuntimeMap = new HashMap();
    private Map jdbcDataSourceRuntimeMap = new HashMap();
    private ObjectName[] serverRT;
    JSONObject monitorResultJson = new JSONObject();

    static {
        try {
            service = new ObjectName("com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean");
        }
        catch (MalformedObjectNameException e) {
            throw new AssertionError(e.getMessage());
        }
    }

    public static String TimeStamp() {
        Calendar cal = Calendar.getInstance();

        String time = String.format("<%04d.%02d.%02d %02d:%02d:%02d>",
                cal.get(Calendar.YEAR),
                (cal.get(Calendar.MONTH) + 1),
                cal.get(Calendar.DAY_OF_MONTH),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                cal.get(Calendar.SECOND)
        );
        return time;
    }

    public static String TimeStamp2() {
        Calendar cal = Calendar.getInstance();

        String time = String.format("[%02d.%02d_%02d:%02d]",
                (cal.get(Calendar.MONTH) + 1),
                cal.get(Calendar.DAY_OF_MONTH),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE)
        );
        return time;
    }

    public static void LoadServer()
    {
        try
        {
            BufferedReader in = new BufferedReader(new FileReader("wls_server_info.ini"));
            String s;

            int count=0;
            while ((s = in.readLine()) != null)
            {
                servers[count]=s;
                count++;
            }
            monitoringInstanceCount=count;
            in.close();
        } catch (IOException e)
        {
            System.err.println(e);
            System.exit(1);
        }
    }

    public static void LoadConfiguration()
    {
        JSONParser parser = new JSONParser();
        try
        {
            Object obj = parser.parse(new FileReader("MonitoringConfig.json"));
            JSONObject jsonObject = (JSONObject) obj;

            serviceName=(String)jsonObject.get("serviceName");
            adminConsoleIP=(String)jsonObject.get("adminConsoleIP");
            adminConsolePort=(String)jsonObject.get("adminConsolePort");
            adminUsername=(String)jsonObject.get("adminUsername");
            adminPassword=(String)jsonObject.get("adminPassword");
            serviceURL=(String)jsonObject.get("serviceURL");
            JSONArray instancesArray= (JSONArray) jsonObject.get("instances");
            monitoringInstanceCount=instancesArray.size();

            for(int i=0 ; i<monitoringInstanceCount ; i++) {
                JSONObject objectInArray = (JSONObject) instancesArray.get(i);

                servers[i]=(String) objectInArray.get("instanceName");
                checkURLs[i]=(String) objectInArray.get("checkUrl");
            }
        } catch (IOException | ParseException e)
        {
            System.err.println(e);
            System.exit(1);
        }
    }

    public void initConnection(String hostname, String portString, String username, String password) throws Exception {
        try {
            if (hostname == null)
                hostname = "127.0.0.1";
            if (portString == null)
                portString = "7001";
            if (username == null)
                username = "weblogic";
            if (password == null)
                password = "weblogic";

            System.out.println(hostname +":"+portString+" "+username +" "+password);
            String protocol = "t3";
            Integer portInteger = Integer.valueOf(portString);
            int port = portInteger.intValue();
            String jndiroot = "/jndi/";
            String mserver = "weblogic.management.mbeanservers.domainruntime";
            JMXServiceURL serviceURL = new JMXServiceURL(protocol, hostname, port,jndiroot + mserver);
            Hashtable h = new Hashtable();
            h.put(Context.SECURITY_PRINCIPAL, username);
            h.put(Context.SECURITY_CREDENTIALS, password);
            h.put(JMXConnectorFactory.PROTOCOL_PROVIDER_PACKAGES, "weblogic.management.remote");
            h.put("jmx.remote.x.request.waiting.timeout", new Long(10000));
            connector = JMXConnectorFactory.connect(serviceURL, h);
            connection = connector.getMBeanServerConnection();
            serverRT = getServerRuntimes();
        } catch(IOException e)
        {
            System.out.println("Admin Server is NOT running!");
            System.out.println(e);

            String time = TimeStamp2();
            BufferedWriter LOG_FILE = new BufferedWriter(new FileWriter("c:\\infapp\\mw.log", true));
            String SMS_MESSAGE = String.format("%sAdminServer:STATE=DOWN", time);
            LOG_FILE.write(SMS_MESSAGE);
            LOG_FILE.newLine();

            LOG_FILE.close();
        }
    }

    /****************************
     * 0. Generate sERVERRuntime
     ***************************/
    public static ObjectName[] getServerRuntimes() throws Exception {
        return (ObjectName[]) connection.getAttribute(service, "ServerRuntimes");
    }

    /************************
     * 1. Generate JVMRuntime
     ***********************/
    private ObjectName getJVMRuntime(ObjectName obj) throws Exception {
        ObjectName JVMRmb = (ObjectName) connection.getAttribute(obj,"JVMRuntime");
        return JVMRmb;
    }

    /**************************
     * 2. Get ThreadPoolRuntime
     **************************/
    private ObjectName getThreadPoolRuntime(ObjectName obj) throws Exception {
        ObjectName threadPoolRmb = (ObjectName) connection.getAttribute(obj,"ThreadPoolRuntime");
        return threadPoolRmb;
    }

    /***************************************
     * 3. Generate JDBCDataSourceRuntime
     ***************************************/
    private ObjectName getJDBCDatasourceRuntime(ObjectName obj)
            throws Exception {
        ObjectName JVMRmb = (ObjectName) connection.getAttribute(obj,"JDBCDataSourceRuntime");
        return JVMRmb;
    }

    private ObjectName getJDBCDriverParamsBean(ObjectName jdbcSystemResourceMBean)
            throws AttributeNotFoundException, InstanceNotFoundException,
            MBeanException, ReflectionException, IOException,
            IntrospectionException {
        ObjectName jdbcDataSourceBean = (ObjectName) getObjectName(
                jdbcSystemResourceMBean, "JDBCResource");

        return (ObjectName) getObjectName(jdbcDataSourceBean, "JDBCDriverParams");
    }

    private Object getObjectName(ObjectName objectName, String attributeName)
            throws AttributeNotFoundException, InstanceNotFoundException,
            MBeanException, ReflectionException, IOException {
        return connection.getAttribute(objectName, attributeName);
    }
    /************************************************
     * 4. Get Mbean object by name and parent MBean
     ************************************************/
    private ObjectName getRuntimeMbean(ObjectName parentMbeanObj, String sonMbeanObj) throws Exception {
        if (connection != null) {
            ObjectName rmb = (ObjectName) connection.getAttribute(parentMbeanObj, sonMbeanObj);
            return rmb;
        } else
            return null;
    }

    /*******************************************************************
     * 5. Iterate through given Mbean and get wanted attribute values
     ******************************************************************/
    public Map getMBeanInfoMap(Vector<String> attrVec, String mBeanTpe)
            throws Exception {
        return null;
    }

    public void CheckInstanceState() throws Exception {
        int length = (int) serverRT.length;
        String name = new String();
        String state = new String();
        Boolean runningFlag = false;


        for (int j = 0; j < monitoringInstanceCount; j++) {
            for (int i = 0; i < length; i++) {
                name = (String) connection.getAttribute(serverRT[i], "Name");
                state = (String) connection.getAttribute(serverRT[i], "State");

                if(servers[j].equals(name)) {
                    runningFlag = true;
                }
            }
            if(runningFlag == true)
            {
                String time = TimeStamp();
                String SERVER_STATE =  String.format("%s [NOTICE-%s] %s %s", time, servers[j], servers[j], "is RUNNING!!!!");
                runningFlag = false;
            }
            else
            {
                String time = TimeStamp();
                String SERVER_STATE =  String.format("%s [CRITICAL-%s] %s %s", time, servers[j], servers[j], "is DOWN!!!! <---");
                System.out.println(SERVER_STATE);

                String time2 = TimeStamp2();
                BufferedWriter LOG_FILE = new BufferedWriter(new FileWriter("c:\\infapp\\mw.log", true));
                String SMS_MESSAGE = String.format("%s%s:STATE=DOWN", time2, servers[j]);
                LOG_FILE.write(SMS_MESSAGE);
                LOG_FILE.newLine();
                LOG_FILE.close();

                runningFlag = false;
            }
        }
    }

    // WebLogic Thread 상태 체크
    public void getThreadHealthCheck(ObjectName on) throws Exception
    {
        String TIME = TimeStamp();
        String SERVER_NAME= new String();
        String threadIdle = new String();
        String activeThreads = new String();
        String stuckThreads = new String();
        String throughput = new String();
        String MESSAGE = new String();

        SERVER_NAME = (String) connection.getAttribute(on, "Name");
        threadIdle= connection.getAttribute(getThreadPoolRuntime(on),"ExecuteThreadIdleCount").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Execute Thread Idle :", threadIdle);
        System.out.println(MESSAGE);

        if(Integer.parseInt(threadIdle) < 2)
        {
            String time2 = TimeStamp2();

            BufferedWriter LOG_FILE = new BufferedWriter(new FileWriter("c:\\infapp\\mw.log", true));
            String SMS_MESSAGE = String.format("%s%s:IdleThread=%s", time2, SERVER_NAME, threadIdle);
            LOG_FILE.write(SMS_MESSAGE);
            LOG_FILE.newLine();
            LOG_FILE.close();
        }

        activeThreads= connection.getAttribute(getThreadPoolRuntime(on),"ExecuteThreadTotalCount").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Active Execute Threads :", activeThreads);
        System.out.println(MESSAGE);

        stuckThreads = connection.getAttribute(getThreadPoolRuntime(on), "StuckThreadCount").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "StuckThreadCount  :", stuckThreads);
        System.out.println(MESSAGE);

        throughput = connection.getAttribute(getThreadPoolRuntime(on), "Throughput").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Throughput  :", throughput);
        System.out.println(MESSAGE);

        // throughput은 단일 모니터링 요소로 처리
        monitorResultJson.put("throughput", throughput);

        // 이외 항목은 Thread로 묶어서 전달
        JSONObject threadResultJon = new JSONObject();
        threadResultJon.put("executeThreadIdleCount", Integer.parseInt(threadIdle));
        threadResultJon.put("executeThreadTotalCount", Integer.parseInt(activeThreads));
        threadResultJon.put("stuckThreadCount", Integer.parseInt(stuckThreads));
        monitorResultJson.put("thread", threadResultJon);
    }

    public void getHeapMemoryHealthCheck(ObjectName on) throws Exception
    {
        String TIME = TimeStamp();
        String resourceValue = new String();
        String SERVER_NAME= new String();
        String MESSAGE = new String();
        String heapFreePercent = new String();
        String heapSizeCurrent = new String();
        String heapFreeCurrent = new String();
        String heapSizeMax = new String();

        SERVER_NAME = (String) (connection.getAttribute(on, "Name"));
        heapFreePercent = connection.getAttribute(getJVMRuntime(on),"HeapFreePercent").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Heap Free Percent(%): ",  heapFreePercent);
        System.out.println(MESSAGE);

        heapSizeCurrent = connection.getAttribute(getJVMRuntime(on),"HeapSizeCurrent").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Heap Size Current: ",  heapSizeCurrent);
        System.out.println(MESSAGE);

        heapSizeMax = connection.getAttribute(getJVMRuntime(on),"HeapSizeMax").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Heap Max Size: ",  heapSizeMax);
        System.out.println(MESSAGE);

        JSONObject heapMemoryResultJon = new JSONObject();
        heapMemoryResultJon.put("currentPercent", heapFreePercent);
        heapMemoryResultJon.put("currentSize", heapSizeCurrent);
        heapMemoryResultJon.put("maxSize", heapSizeMax);
        monitorResultJson.put("heapMemory", heapMemoryResultJon);
    }

    public void getDBPoolHealthCheck(ObjectName on) throws Exception {
        String TIME = TimeStamp();
        String resourceValue = new String();
        String SERVER_NAME= new String();
        String MESSAGE = new String();
        JSONArray datasourceArray = new JSONArray();

        SERVER_NAME = (String) connection.getAttribute(on, "Name");
        ObjectName[] appRT = (ObjectName[]) connection.getAttribute(
                new ObjectName("com.bea:Name=" + SERVER_NAME + ",ServerRuntime="
                        + SERVER_NAME + ",Location=" + SERVER_NAME
                        + ",Type=JDBCServiceRuntime"),
                "JDBCDataSourceRuntimeMBeans");
        int appLength = (int) appRT.length;

        if (appLength == 0) {
            resourceValue = "null";
            MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "DB Connection Pool: ",  resourceValue);
            System.out.println(MESSAGE);
        }

        for (int x = 0; x < appLength; x++) {
            JSONObject datasourceObject = new JSONObject();

            String poolName = (String) connection.getAttribute(appRT[x], "Name");
            System.out.println(String.format("%s [NOTICE-%s] Name: %s ", TIME, SERVER_NAME, poolName));
            datasourceObject.put("poolName", poolName);

            String connectionsTotalCount = (connection.getAttribute(appRT[x],"ConnectionsTotalCount")).toString();
            System.out.println(String.format("%s [NOTICE-%s]     - %s %s ", TIME, SERVER_NAME, "connectionsTotalCount:", connectionsTotalCount));
            datasourceObject.put("maxSize", connectionsTotalCount);

            String numAvailable = connection.getAttribute(appRT[x],"NumAvailable").toString();
            System.out.println(String.format("%s [NOTICE-%s]     - %s %s ", TIME, SERVER_NAME, "NumAvailable:", numAvailable));
            datasourceObject.put("idleCount", numAvailable);

            if(Integer.parseInt(numAvailable) < 5)
            {
                String time = TimeStamp();
                String time2 = TimeStamp2();
                String SERVER_STATE =  String.format("%s [CRITICAL-%s] %s %s", time, SERVER_NAME, poolName, " Pool Check!!! ");
                System.out.println(SERVER_STATE);

                BufferedWriter LOG_FILE = new BufferedWriter(new FileWriter("c:\\infapp\\mw.log", true));
                String SMS_MESSAGE = String.format("%s%s:%s_Pool=%s",time2, SERVER_NAME, poolName, numAvailable);
                LOG_FILE.write(SMS_MESSAGE);
                LOG_FILE.newLine();
                LOG_FILE.close();
            }
            String activeConnectionsCurrentCount = connection.getAttribute(appRT[x],"ActiveConnectionsCurrentCount").toString();
            System.out.println(String.format("%s [NOTICE-%s]     - %s %s ", TIME, SERVER_NAME, "ActiveConnectionsCurrentCount:", activeConnectionsCurrentCount));
            datasourceObject.put("activeCount", activeConnectionsCurrentCount);

            String leakedConnectionCount = connection.getAttribute(appRT[x],"LeakedConnectionCount").toString();
            System.out.println(String.format("%s [NOTICE-%s]     - %s %s ", TIME, SERVER_NAME, "LeakedConnectionCount:", leakedConnectionCount));
            datasourceObject.put("leakCount", leakedConnectionCount);

            datasourceArray.add(datasourceObject);
        }
        monitorResultJson.put("dbPoolList", datasourceArray);


    }

    public void getInstanceHealthCheck(ObjectName on) throws Exception
    {
        String TIME = TimeStamp();
        String resourceValue = new String();
        String SERVER_NAME= new String();
        String MESSAGE = new String();

        String hostName = InetAddress.getLocalHost().getHostName().toString();
        monitorResultJson.put("hostName", hostName);

        String serverIP = InetAddress.getLocalHost().getHostAddress().toString();
        monitorResultJson.put("serverIP", serverIP);

        resourceValue = connection.getAttribute(on,"Name").toString();
        SERVER_NAME = resourceValue;
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, SERVER_NAME, "Instance : ", resourceValue);
        System.out.println(MESSAGE);
        monitorResultJson.put("instanceName", resourceValue);

        resourceValue = connection.getAttribute(on,"State").toString();
        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME,  SERVER_NAME, "State : ", resourceValue);
        System.out.println(MESSAGE);
        monitorResultJson.put("state", resourceValue);
    }

    public void closeCollector() throws Exception {
        connector.close();
    }

    public void toJasonServiceName(String serviceName) throws Exception {
        monitorResultJson.put("serviceName", serviceName);
    }

    public void getUrlsCheck(String [] urls) throws Exception {
        int countUrls = (int) urls.length;
        JSONArray urlCheckArray = new JSONArray();

        for(int i=0 ; i<countUrls ; i++)
        {
            String serverIP = InetAddress.getLocalHost().getHostAddress().toString();
            String checkUrl = "http://" + serverIP + urls[i];
            urlHealthCheck a = new urlHealthCheck(checkUrl);
            JSONObject urlCheckObject = new JSONObject();
            Boolean urlCheck = a.checkUrlHealth();

            urlCheckObject.put("url", urls[i]);

            if (urlCheck == true) {
                urlCheckObject.put("urlCheck", "OK");
            }
            else {
                urlCheckObject.put("urlCheck", "NOT_OK");
            }
            urlCheckArray.add(urlCheckObject);
        }
        monitorResultJson.put("urlList", urlCheckArray);
    }

    public void getUrlCheck(String url) throws Exception {
        String serverIP = InetAddress.getLocalHost().getHostAddress().toString();
        String checkUrl = url;
        urlHealthCheck a = new urlHealthCheck(checkUrl);
        JSONObject urlCheckObject = new JSONObject();
        Boolean urlCheck = a.checkUrlHealth();

        urlCheckObject.put("url", url);

        if (urlCheck) {
            monitorResultJson.put("urlCheck", "OK");
        }
        else {
            monitorResultJson.put("urlCheck", "NOT_OK");
        }
    }

    // HTTP POST request
    private void sendPost(String url, String urlParameters) throws Exception {
        String TIME = TimeStamp();
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        //add reuqest header
        con.setRequestMethod("POST");
        //con.setRequestProperty("User-Agent", USER_AGENT);
        //con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("Content-Type", "application/json");
        con.setConnectTimeout(10000);       //컨텍션타임아웃 10초
        con.setReadTimeout(5000);           //컨텐츠조회 타임아웃 5총
        con.setDoOutput(true);              //항상 갱신된내용을 가져옴.

        // Send post request
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(urlParameters);
        wr.flush();
        wr.close();

        int responseCode = con.getResponseCode();
        System.out.println(String.format("%s [INFO] Collection Server: %s", TIME, url));
        System.out.println(String.format("%s [INFO] Parameters: %s", TIME, urlParameters));
        System.out.println(String.format("%s [INFO] ResponseCode from Collection Server: %s", TIME, responseCode));

        Charset charset = Charset.forName("UTF-8");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(),charset));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
    }

    public static void main(String[] args) throws Exception {
        for(int count=0 ; count < 960; count++)
        {
            try {
                LoadConfiguration();
                wlsMonitor s = new wlsMonitor();
                s.initConnection(adminConsoleIP, adminConsolePort, adminUsername, adminPassword);
                int length = (int) s.serverRT.length;

                // 모니터링 대상 중에 미기동 상태인 인스턴스 정보 전송
                String[] runningInstances = new String[40];
                for (int i = 0; i < length; i++) {
                    runningInstances[i] = (String) connection.getAttribute(s.serverRT[i], "Name");
                }

                for (int i=0 ; i<monitoringInstanceCount ; i++) {
                    Boolean instanceRunningCheck = Arrays.asList(runningInstances).contains(servers[i]);

                    if (!instanceRunningCheck) {
                        String TIME = TimeStamp();
                        String resourceValue = servers[i];
                        String MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME, servers[i], "Instance : ", servers[i]);
                        System.out.println(MESSAGE);

                        s.toJasonServiceName(serviceName);
                        s.monitorResultJson.put("instanceName", resourceValue);

                        MESSAGE = String.format("%s [NOTICE-%s] %-22s  %-15s", TIME,  servers[i], "State : ", "SHUTDOWN");
                        System.out.println(MESSAGE);
                        s.monitorResultJson.put("state", "SHUTDOWN");

                        String d1 = (s.monitorResultJson).toString();
                        s.sendPost("http://localhost:8080/api/users", d1);
                    }
                }

                // 모니터링 대상 인스턴스 상태 체크
                if (length > 0 ) {
                    for (int i = 0; i < length; i++)
                    {
                        for (int j = 0; j < monitoringInstanceCount; j++) {
                            String name = (String) connection.getAttribute(s.serverRT[i], "Name");

                            if(servers[j].equals(name)) {
                                System.out.println("================================================================");
                                s.toJasonServiceName(serviceName);
                                s.getInstanceHealthCheck(s.serverRT[i]);
                                s.getThreadHealthCheck(s.serverRT[i]);
                                s.getHeapMemoryHealthCheck(s.serverRT[i]);
                                s.getDBPoolHealthCheck(s.serverRT[i]);
                                s.getUrlCheck(checkURLs[j]);
                                String d1 = (s.monitorResultJson).toString();
                                s.sendPost("http://localhost:8080/api/users", d1);
                            }
                        }
                    }
                }

                Thread.sleep(5000);
                connector.close();
            } catch (Exception e) {
                System.out.println(e);
                Thread.sleep(5000);
            }
        }
    }
}

