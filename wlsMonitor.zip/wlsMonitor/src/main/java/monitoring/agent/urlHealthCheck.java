package monitoring.agent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.*;
import java.util.Calendar;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class urlHealthCheck {
    String checkURL = new String();
    boolean healthStatus = true;

    urlHealthCheck(String url) {
        this.checkURL = url;
    }

    public boolean checkUrlHealth() {

        // HttpClient 생성
        HttpClient httpclient = new DefaultHttpClient();
        String TIME = TimeStamp();

        try {
            // HttpGet생성
            HttpGet httpget = new HttpGet(checkURL);

            HttpResponse response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity();

            // 응답 결과
            //System.out.println(response.getStatusLine());
            if (entity != null) {
                BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            }
            httpget.abort();
            httpclient.getConnectionManager().shutdown();

        } catch (ClientProtocolException e) {
            healthStatus = false;
        } catch (IOException e) {
            healthStatus = false;
        } finally {
            httpclient.getConnectionManager().shutdown();
        }

        if (healthStatus) {
            System.out.println(String.format("%s [URL_CHECK:%s] %s", TIME, this.checkURL, "OK"));
            return true;
        }
        else {
            SendSMS(checkURL, "mw_mon.log");
            System.out.println(String.format("%s [URL_CHECK:%s] %s", TIME, this.checkURL, "NOT_OK"));
            return false;
        }
    }

    public static String TimeStamp() {
        Calendar cal = Calendar.getInstance();

        String time = String.format("<%04d.%02d.%02d %02d:%02d:%02d>",
                cal.get(Calendar.YEAR),
                (cal.get(Calendar.MONTH) + 1),
                cal.get(Calendar.DAY_OF_MONTH),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                cal.get(Calendar.SECOND)
        );
        return time;
    }

    public static String TimeStamp2() {
        Calendar cal = Calendar.getInstance();

        String time = String.format("[%02d.%02d_%02d:%02d]",
                (cal.get(Calendar.MONTH) + 1),
                cal.get(Calendar.DAY_OF_MONTH),
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE)
        );
        return time;
    }

    public static void SendSMS(String test_url, String logfile) {
        try {
            String TIME = TimeStamp();
            BufferedWriter LOG_FILE = new BufferedWriter(new FileWriter(logfile, true));
            String SMS_MESSAGE = String.format("URL_CHECK_ERROR:%s", test_url);
            LOG_FILE.write(SMS_MESSAGE);
            LOG_FILE.newLine();
            LOG_FILE.close();
        } catch (IOException file_open_error) {
            System.out.println("Can't Open mw.log file. . .");
        }
    }

}